"use client";

import { useState } from "react";
import Link from "next/link";
import { Minus, Plus, MessageCircle, Phone } from "lucide-react";
import { formatDateLabel, formatPrice } from "@/lib/utils";
import { buildWhatsAppLink, buildTelLink } from "@/lib/whatsapp";

export function PackageBookingCard({
  slug,
  title,
  price,
  originalPrice,
  slotsLeft,
  availableDates,
  availableFrom,
  availableTo,
  whatsappNumber,
}: {
  slug: string;
  title: string;
  price: number;
  originalPrice?: number | null;
  slotsLeft?: number | null;
  availableDates?: string[] | null;
  availableFrom?: string | null;
  availableTo?: string | null;
  whatsappNumber?: string;
}) {
  const [travellers, setTravellers] = useState(2);
  const [date, setDate] = useState("");
  const hasFixedDates = (availableDates?.length ?? 0) > 0;

  const bookingHref = `/booking?package=${encodeURIComponent(slug)}&travellers=${travellers}${
    date ? `&date=${encodeURIComponent(date)}` : ""
  }`;

  const whatsappHref = buildWhatsAppLink(
    `Hello! I would like to book *${title}* for ${travellers} traveller(s). Could you share availability and next steps?${
      date ? `\n\n📅 Selected Date: ${date}` : ""
    }`,
    whatsappNumber
  );

  const totalPrice = price * travellers;
  const totalOriginal = originalPrice ? originalPrice * travellers : null;
  const savings = totalOriginal ? totalOriginal - totalPrice : null;

  return (
    <div className="rounded-[20px] border border-border/80 bg-surface p-6 shadow-md sm:p-7">
      {/* Slots Left Banner */}
      {slotsLeft != null && (
        <div
          className={`mb-4 flex items-center justify-between rounded-xl p-3 text-xs font-bold ${
            slotsLeft === 0
              ? "bg-rose-50 border border-rose-200 text-rose-800"
              : "bg-amber-50 border border-amber-200 text-amber-900"
          }`}
        >
          <span className="flex items-center gap-1.5">
            <span className="relative flex h-2 w-2">
              <span
                className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                  slotsLeft === 0 ? "bg-rose-400" : "bg-amber-400"
                }`}
              />
              <span
                className={`relative inline-flex rounded-full h-2 w-2 ${
                  slotsLeft === 0 ? "bg-rose-500" : "bg-amber-500"
                }`}
              />
            </span>
            {slotsLeft === 0
              ? "Batch Sold Out — Contact for Next Dates"
              : `Hurry! Only ${slotsLeft} ${slotsLeft === 1 ? "slot" : "slots"} remaining for next batch`}
          </span>
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-700 bg-amber-200/60 px-1.5 py-0.5 rounded">
            Live
          </span>
        </div>
      )}

      <div className="flex items-baseline justify-between">
        <div>
          <div className="flex items-baseline gap-2">
            {originalPrice && originalPrice > price && (
              <span className="text-sm text-ink-muted line-through">{formatPrice(originalPrice)}</span>
            )}
            <span className="text-3xl font-extrabold text-ink tracking-tight">{formatPrice(price)}</span>
            <span className="text-sm font-medium text-ink-muted">/ person</span>
          </div>
          <p className="mt-0.5 text-[11px] font-semibold uppercase tracking-wider text-ink-muted">Starting price</p>
        </div>
        {savings && savings > 0 && (
          <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700 border border-emerald-200">
            Save {formatPrice(savings)}
          </span>
        )}
      </div>

      <div className="mt-6 space-y-4">
        <div>
          <label className="text-[11px] font-bold uppercase tracking-wider text-ink-muted">Travellers</label>
          <div className="mt-2 flex items-center justify-between rounded-[12px] border border-border/80 bg-sage-100/50 px-4 py-2.5">
            <button
              type="button"
              onClick={() => setTravellers((t) => Math.max(1, t - 1))}
              className="rounded-full p-1 text-ink hover:bg-sage-200 transition-colors"
              aria-label="Decrease travellers"
            >
              <Minus className="h-4 w-4" />
            </button>
            <span className="font-bold text-ink text-base">{travellers} {travellers === 1 ? "Person" : "People"}</span>
            <button
              type="button"
              onClick={() => setTravellers((t) => Math.min(20, t + 1))}
              className="rounded-full p-1 text-ink hover:bg-sage-200 transition-colors"
              aria-label="Increase travellers"
            >
              <Plus className="h-4 w-4" />
            </button>
          </div>
        </div>

        <div>
          <label htmlFor="travel-date" className="text-[11px] font-bold uppercase tracking-wider text-ink-muted">
            {hasFixedDates ? "Choose a Departure Date" : "Preferred Travel Date"}
          </label>
          {hasFixedDates ? (
            <select
              id="travel-date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="mt-2 w-full rounded-[12px] border border-border/80 bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-canopy transition-all"
            >
              <option value="">Select a date</option>
              {availableDates!.map((d) => (
                <option key={d} value={d}>
                  {formatDateLabel(d)}
                </option>
              ))}
            </select>
          ) : (
            <input
              id="travel-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              min={availableFrom || undefined}
              max={availableTo || undefined}
              className="mt-2 w-full rounded-[12px] border border-border/80 bg-surface px-4 py-2.5 text-sm text-ink outline-none focus:border-canopy transition-all"
            />
          )}
        </div>

        {/* Dynamic Total Price Row */}
        <div className="rounded-[12px] bg-canopy/5 border border-canopy/15 p-3.5 flex items-center justify-between">
          <span className="text-xs font-bold text-ink/80">Total Price ({travellers} {travellers === 1 ? "guest" : "guests"}):</span>
          <span className="text-lg font-extrabold text-canopy">{formatPrice(totalPrice)}</span>
        </div>
      </div>

      <div className="mt-6 space-y-2.5">
        <Link
          href={bookingHref}
          className="flex w-full items-center justify-center rounded-[12px] bg-canopy hover:bg-canopy-hover px-5 py-3.5 text-sm font-bold text-white shadow-xs transition-colors"
        >
          Book Now — {formatPrice(totalPrice)}
        </Link>
        <a
          href={whatsappHref}
          target="_blank"
          rel="noreferrer"
          className="flex w-full items-center justify-center gap-2 rounded-[12px] border border-border/80 bg-surface px-5 py-3.5 text-sm font-bold text-ink transition-colors hover:bg-sage-100"
        >
          <MessageCircle className="h-4 w-4 text-[#25D366]" /> Chat on WhatsApp
        </a>
        <a
          href={buildTelLink(whatsappNumber)}
          className="flex w-full items-center justify-center gap-2 rounded-[12px] border border-border/80 bg-surface px-5 py-3.5 text-sm font-bold text-ink transition-colors hover:bg-sage-100"
        >
          <Phone className="h-4 w-4 text-canopy" /> Enquire / Call Us
        </a>
      </div>

      <div className="mt-6 pt-5 border-t border-border/70 space-y-2 text-xs text-ink-muted">
        {/* These three lines are commitments to a paying customer, so each one
            has to match what the business actually does. The previous copy
            promised instant confirmation (there is no booking engine — every
            trip is confirmed by a consultant) and "free cancellation up to 48
            hours", which directly contradicted /cancellation-policy, where
            anything inside 7 days is non-refundable. */}
        <div className="flex items-center gap-2">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 font-bold text-[10px]">✓</span>
          <span>Confirmed personally by a trip consultant</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 font-bold text-[10px]">✓</span>
          <span>
            Up to 90% refund —{" "}
            <Link href="/cancellation-policy" className="underline underline-offset-2 hover:text-ink">
              see cancellation policy
            </Link>
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="flex h-5 w-5 items-center justify-center rounded-full bg-emerald-100 text-emerald-700 font-bold text-[10px]">✓</span>
          <span>Transparent pricing — ask what&apos;s included</span>
        </div>
      </div>
    </div>
  );
}
