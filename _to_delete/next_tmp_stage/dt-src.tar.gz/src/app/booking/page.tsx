// Package fields read here (title/image/price/duration/location) rarely
// change minute-to-minute, so this is safe to cache same as the rest of
// the content pages.
export const revalidate = 60;

import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { createPublicSupabaseClient } from "@/lib/supabase.server";
import { Container } from "@/components/ui/Container";
import { formatPrice } from "@/lib/utils";
import { BookingForm } from "@/components/packages/BookingForm";
import { cldUrl } from "@/lib/cloudinary";

// Cast needed below: the Supabase client has no generated Database type, so
// TypeScript infers query results as `never` instead of the real row shape.
// See supabase_schema.md — generating types would remove this.
type BookingPackage = {
    id: string;
    slug: string;
    title: string;
    image: string | null;
    price: number;
    duration: string | null;
    location: string | null;
    available_dates: string[] | null;
    available_from: string | null;
    available_to: string | null;
};

export default async function BookingPage({
    searchParams,
}: {
    searchParams: Promise<{ package?: string; travellers?: string; date?: string; available_from?: string; available_to?: string }>;
}) {
    const { package: slug, travellers, date, available_from, available_to } = await searchParams;

    if (!slug) {
        notFound();
    }

    const supabase = createPublicSupabaseClient();
    const { data } = await supabase
        .from("packages")
        .select("id,slug,title,image,price,duration,location,available_dates,available_from,available_to")
        .eq("slug", slug)
        .maybeSingle();
    const pkg = data as BookingPackage | null;

    if (!pkg) {
        notFound();
    }

    return (
        <main className="flex-1 bg-canvas pt-24 sm:pt-28 lg:pt-32 pb-12">
            <Container className="max-w-3xl">
                <p className="text-sm font-semibold uppercase tracking-wide text-primary">Complete your enquiry</p>
                <h1 className="display-section mt-2 text-3xl text-ink">Book {pkg.title}</h1>
                <p className="mt-2 text-sm text-ink/60">
                    Share your details and our travel desk will confirm availability and next steps over
                    WhatsApp or phone.
                </p>

                <div className="mt-8 grid gap-8 sm:grid-cols-[220px_1fr]">
                    <div className="relative aspect-[4/3] w-full overflow-hidden rounded-[16px] border border-border">
                        {pkg.image && (
                            <Image src={cldUrl(pkg.image, 440)} alt={pkg.title} fill sizes="220px" className="object-cover" />
                        )}
                    </div>
                    <div>
                        <h2 className="font-semibold text-ink">{pkg.title}</h2>
                        <p className="mt-1 text-sm text-ink/60">{pkg.location} · {pkg.duration}</p>
                        <p className="mt-2 text-lg font-bold text-ink">{formatPrice(pkg.price)} <span className="text-sm font-normal text-ink/60">/ person</span></p>
                        <Link href={`/packages/${pkg.slug}`} className="mt-2 inline-block text-sm text-primary hover:underline">
                            View full package details
                        </Link>
                    </div>
                </div>

                <div className="mt-10 rounded-[20px] border border-border bg-surface p-6 sm:p-8">
                    <BookingForm
                        packageTitle={pkg.title}
                        defaultTravellers={travellers ? Number(travellers) : 2}
                        defaultDate={date ?? ""}
                        availableDates={pkg.available_dates}
                        availableFrom={pkg.available_from ?? available_from}
                        availableTo={pkg.available_to ?? available_to}
                        whatsappNumber={process.env.NEXT_PUBLIC_WHATSAPP_NUMBER}
                    />
                </div>
            </Container>
        </main>
    );
}
